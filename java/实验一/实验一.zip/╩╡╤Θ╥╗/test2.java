package ʵ��һ;

public class test2 {

	public static void main(String[] args) {
		int a=12345678;
		boolean b=true;
		double c=3.14159;
		char d='\\';
		System.out.println(a+","+b+","+c+","+d);		
	}

}
