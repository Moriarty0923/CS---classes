package ʵ��һ;

public class test3 {

	public static void main(String[] args) {
		int a=(int)(Math.random()*100);
		System.out.println(a);
	}

}
