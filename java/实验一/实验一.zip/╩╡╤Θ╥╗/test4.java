package ʵ��һ;

public class test4 {

	public static void main(String[] args) {
		int a=20 ;
		int b=++a;
		System.out.println(a+","+b);
	}
}
