package ʵ��һ;

public class Test1 {
	public static void main(String[] args) {
		System.out.println("this is a simple java application");
				Student stu=new Student();
				stu.speak("Welcome,new students!");
				}
			}
		class Student{
		public void speak(String s){
		System.out.println(s);
			}
		}
