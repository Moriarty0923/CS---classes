package ʵ��һ;

public class test5 {

	public static void main(String[] args) {
		int a=20;
		double b=3.2;
		System.out.println(a%b);

	}

}
