package ʵ����;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class Queryhandler implements ActionListener{
	
	private QueryFrame query;
	int datanum=0;
	int queresnum=0;
	HumanInfo []info= new HumanInfo[1000];			//���ڴ�����еļ�¼
	HumanInfo []queryres = new HumanInfo[100];		//���ڼ�¼���ҵĽ��
	
	public Queryhandler(QueryFrame query) {
		this.query=query;
	}
	
	//��ȡ�ļ��е����ݣ�����Ϣ��ŵ�info������
	public void getinfo() {
		System.out.println("��ʼ����...");
		File file=new File("D:\\eclipse java\\java�γ�ʵ��\\src\\ʵ����\\src.txt");
		BufferedReader reader=null;
		String temp=null;
		int line=0;
		try{
			InputStreamReader fReader = new InputStreamReader(new FileInputStream(file),"UTF-8");
			reader = new BufferedReader(fReader);
		   while((temp=reader.readLine())!=null){
			    HumanInfo temphuman=new HumanInfo(temp);
			    info[line]=temphuman;
			    line++;
		   }
		   datanum=line--;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(reader!=null){
				try{
					reader.close();
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
		}
	}
	
	//������ҵ��ļ�¼
	public void saveinfo(HumanInfo []arry) {
		System.out.println("���ڱ���...");
		//����bufferedwriter����
        BufferedWriter bw = null;
        //����FileWriter����
        FileWriter fw = null;
        try {

            fw = new FileWriter("D:\\eclipse java\\java�γ�ʵ��\\src\\ʵ����\\rst.txt");
            bw = new BufferedWriter(fw);
            for(HumanInfo temp:arry) {
            	String s=String.format("%-22s%-10s%-5s%-30s",temp.id,temp.name,temp.age,temp.email);
            	bw.write(s+"\n");
            }
        }catch (Exception e) {
            e.printStackTrace();
        } finally {
        	
            if (bw != null) {
                try {
                    {
                        bw.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } 
	}
	
	//�������в��ҷ�������ļ�¼
	public void anlyinfo(String id,String name,int age,String email) {
		int index=0;
		for(int i=0;i<datanum;i++) {
			if(age!=0&&info[i].age!=age) continue;
			else if(id!=""&&info[i].id.indexOf(id)!=-1) {queryres[index]=info[i];index++;continue;}
			else if(name!=""&&info[i].name.indexOf(name)!=-1) {queryres[index]=info[i];index++;continue;}
			else if(email!=""&&info[i].email.indexOf(email)!=-1) {queryres[index]=info[i];index++;continue;}
			else if(info[i].age==age) {queryres[index]=info[i];index++;continue;}
		}
		queresnum=index--;
	}

	
	public void actionPerformed(ActionEvent e) {
		//��ȡ�ı������������Ϣ���ֱ������ʱ����
		String	id,name,email;
		int age;
		if(query.getlabelid().getText().isEmpty()) id="";
		else id=query.getlabelid().getText();
		if(query.getlabelname().getText().isEmpty()) name="";
		else name=query.getlabelname().getText();
		if(query.getlabelage().getText().isEmpty()) age=0;
		else age=Integer.parseInt(query.getlabelage().getText());
		if(query.getlabelemail().getText().isEmpty()) email="";
		else email=query.getlabelemail().getText();
		getinfo();
	
		anlyinfo(id,name,age,email);
		if(queresnum==0) {
			System.out.println("û�в�ѯ����¼");
		}
		else {
			System.out.println("���ҽ������:");
			System.out.printf("%-20s%-10s%-5s%-30s","���","����","����","����");
			System.out.println("");
			HumanInfo []newArray = Arrays.copyOfRange(queryres, 0, queresnum);
			Arrays.sort(newArray,new HumanComparator());	//����
			for(int t=0;t<queresnum;t++) {
				newArray[t].showhuman();
			}
			saveinfo(newArray);
			System.out.println("������ϡ�");
		}
	}
}
